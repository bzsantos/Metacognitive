/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ap.dados;

import bz.metric.control.AdicionaTag;
import bz.metric.control.PostControl;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Bruno
 */
public class cadastraServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
//        try (PrintWriter out = response.getWriter()) {
//            /* TODO output your page here. You may use following sample code. */
//            out.println("<!DOCTYPE html>");
//            out.println("<html>");
//            out.println("<head>");
//            out.println("<title>Servlet cadastraServlet</title>");            
//            out.println("</head>");
//            out.println("<body>");
//            out.println("<h1>Servlet cadastraServlet at " + request.getContextPath() + "</h1>");
//            out.println("</body>");
//            out.println("</html>");
//        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        
        HttpSession session = request.getSession();
        
        PostControl p = new PostControl();
        
        
        
        String tag1 = (String) session.getAttribute("valor1");
        String tag2 = (String) session.getAttribute("valor2");
        String tag3 = (String) session.getAttribute("valor3");
        String tag4 = (String) session.getAttribute("valor4");
        String titulo = (String) session.getAttribute("gp");
        String subtitulo = (String) session.getAttribute("sub");
        //String tags = request.getParameter("tag1"); 
//        String titulo = request.getParameter("titulo"); 
//        String subtitulo = request.getParameter("assunto"); 
        
        //String nome = (String) session.getAttribute("nome");
        String foto = (String) session.getAttribute("foto");
        int id = (int) session.getAttribute("id");
        
        p.setUsuario(id);
        p.setGrupotitulo(titulo);
        p.setSubtitulo(subtitulo);
        p.setTag1(tag1);
        p.setTag2(tag2);
        p.setTag3(tag3);
        p.setTag4(tag4);
        p.setFoto(foto);        
       
        
        p.cadpost(p.getGrupotitulo(), p.getSubtitulo(), p.getTag1(), p.getTag2(), p.getTag3(), p.getTag4(), p.getFoto(), p.getUsuario());
        
        response.sendRedirect("cadtag.jsp");
        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);

        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();

        AdicionaTag at = new AdicionaTag();

       

        try {
    
            String gp = request.getParameter("grupo");
            String sub = request.getParameter("subgrupo");
            // String tgs = (String) session.getAttribute("valor1");       
            String tags = request.getParameter("tag");
            
            session.setAttribute("gp", gp);
            session.setAttribute("sub", sub);
            // session.setAttribute("tgs", tgs);
            session.setAttribute("tag", tags);
            
            
            String tg = tags;
            
            if(at.confere(tg) == true){
            
            String dado1 = at.minhastag().get(0);
            String dado2 = at.minhastag().get(1);
            String dado3 = at.minhastag().get(2);
            
            
            session.setAttribute("dado1", dado1);
            session.setAttribute("dado2", dado2);
            session.setAttribute("dado3", dado3);
            
            } else {
                
            String dado1 = "";
            String dado2 = "";
            String dado3 = "";
            
            
            session.setAttribute("dado1", dado1);
            session.setAttribute("dado2", dado2);
            session.setAttribute("dado3", dado3);
                
            }
           /** if(tags.equals(dado1)){
                tg = "";
                  session.setAttribute("dado1", dado1);
                  session.setAttribute("dado2", dado2);
                  session.setAttribute("dado3", dado3);  
                  session.setAttribute("tag", tg);
            } else if(tags.equals(dado2)){
                tg = "";
                  session.setAttribute("dado1", dado1);
                  session.setAttribute("dado2", dado2);
                  session.setAttribute("dado3", dado3);  
                  session.setAttribute("tag", tg);
            } else if(tags.equals(dado3)){
                tg = "";
                  session.setAttribute("dado1", dado1);
                  session.setAttribute("dado2", dado2);
                  session.setAttribute("dado3", dado3);  
                  session.setAttribute("tag", tg);
            } else {
            

            session.setAttribute("dado1", dado1);
            session.setAttribute("dado2", dado2);
            session.setAttribute("dado3", dado3);   
            session.setAttribute("tag", tags);

           
            } */
            
             response.sendRedirect("dados.jsp");
//        try {
//            MetatagDAO mt = new MetatagDAO();
//            List<Metasort> res = mt.listatags();
//            
//         //   DefaultComboBoxModel comboModel = (DefaultComboBoxModel) cbMeta.getModel();
//
//            
//            if(at.confere(tg) == false){
//               // JOptionPane.showMessageDialog(null, "Não há esse metadado no vetor carregado!, escolha um do vetor");
//             //   txtInsere.setText("");
//                
//              //  btnInserir.setEnabled(false);
//             //   txtInsere.setEnabled(false);
//              //  cbMeta.setEnabled(true);
//
//                for(int i=0;i<res.size();i++){
//                    
//                String tag = res.get(i).getTagsort();
//                
//              //  comboModel.addElement(tag);
//                }
//            }
//            

        } catch (SQLException ex) {
            Logger.getLogger(cadastraServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

        //response.sendRedirect("dados.jsp");
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
