/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ap.dados;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Bruno
 */
public class dadosServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
//        try (PrintWriter out = response.getWriter()) {
//            /* TODO output your page here. You may use following sample code. */
//            out.println("<!DOCTYPE html>");
//            out.println("<html>");
//            out.println("<head>");
//            out.println("<title>Servlet dadosServlet</title>");            
//            out.println("</head>");
//            out.println("<body>");
//            out.println("<h1>Servlet dadosServlet at " + request.getContextPath() + "</h1>");
//            out.println("</body>");
//            out.println("</html>");
//        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();
        
//        
//        String dado1 = "dado1";
//        String dado2 = "dado2";
//        String dado3 = "dado3";
        
        
        
        String grupo = request.getParameter("grupo");   
        String subgrupo = request.getParameter("subgrupo");
        String tag = request.getParameter("tag");
        
//        if(!tag.equals(dado1) && !tag.equals(dado2) && !tag.equals(dado3)){
//            
//        }
//        
        
        
        session.setAttribute("grupo", grupo);
        session.setAttribute("subgrupo", subgrupo);
        session.setAttribute("tag", tag);

        response.sendRedirect("dados.jsp");
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        
        PrintWriter out = response.getWriter();
        
        HttpSession session = request.getSession();
        
//        
//        MetatagDAO grupodao = new MetatagDAO();
//        GrupotagDAO gt =  new GrupotagDAO();
//
//        List<Metatags> resultado;
//         String[] metacerto = new String[4];
//        
//        try {
//            resultado = grupodao.findGrupoTags();
//            
//            metacerto[0] = resultado.get(0).getTags();
//            metacerto[1] = resultado.get(1).getTags();
//            metacerto[2] = resultado.get(2).getTags();
//            
//        } catch (SQLException ex) {
//            Logger.getLogger(dadosServlet.class.getName()).log(Level.SEVERE, null, ex);
//        }
//   
//        String dado1 = metacerto[0];
//        String dado2 = metacerto[1];
//        String dado3 = metacerto[2];
      
        
        
//        String dado1 = "dado1";
//        String dado2 = "dado2";
//        String dado3 = "dado3";
//        String cog1 = "1";
//        String cog2 = "2";
//        String cog3 = "3";
//        
//        String s = "S";
//        String a = "A";
//        String i = "I";
//        
//        String teste;
//        
//        String img1 = "<img src=\"img/sa.png\" class=\"img-fluid\" alt=\"\">";
//        String img2 = "<img src=\"img/ad.png\" class=\"img-fluid\" alt=\"\">";
//        String img3 = "<img src=\"img/in.png\" class=\"img-fluid\" alt=\"\">";
        
        
//        double x = 0.6;
//        
//        if(x < 0.0){
//            teste = img3;
//        } else if(x > 0.5 && x < 0.8){
//            teste = img2;
//        } else {
//            teste = img1;
//        }
         
        String valor1=request.getParameter("tag1");
        String valor2=request.getParameter("tag2");
        String valor3=request.getParameter("tag3");
        String valor4=request.getParameter("tag4");
        
        session.setAttribute("valor1", valor1);
        session.setAttribute("valor2", valor2);
        session.setAttribute("valor3", valor3);
        session.setAttribute("valor4", valor4);
       // String imagem = teste;

        //session.setAttribute("img", imagem);
      
        //session.setAttribute("dado6", dado6);  
//        session.setAttribute("dado1", dado1);
//        session.setAttribute("dado2", dado2);
//        session.setAttribute("dado3", dado3);
        //session.setAttribute("cog1", cog1);
       // session.setAttribute("cog2", cog2);
       // session.setAttribute("cog3", cog3);

        response.sendRedirect("dados.jsp");

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
