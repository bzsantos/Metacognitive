package bz.metric.model;

/**
 *
 * @author bzsantos
 */
public class Metasort {

    int idmetasort;
    int folkssort;
    String tagsort;
    int gruposort;
    int usersort;

    public int getIdmetasort() {
        return idmetasort;
    }

    public void setIdmetasort(int idmetasort) {
        this.idmetasort = idmetasort;
    }

    public int getFolkssort() {
        return folkssort;
    }

    public void setFolkssort(int folkssort) {
        this.folkssort = folkssort;
    }

    public String getTagsort() {
        return tagsort;
    }

    public void setTagsort(String tagsort) {
        this.tagsort = tagsort;
    }

    public int getGruposort() {
        return gruposort;
    }

    public void setGruposort(int gruposort) {
        this.gruposort = gruposort;
    }

    public int getUsersort() {
        return usersort;
    }

    public void setUsersort(int usersort) {
        this.usersort = usersort;
    }

   
    
    
    
    
    

}
