/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bz.metric.model;

/**
 *
 * @author bzsantos
 */
public class Metaini {

    private int idmeta;
    private int user;
    private String tagini;
    private String link;
    private int grupo;
   

    public int getIdmeta() {
        return idmeta;
    }

    public void setIdmeta(int idmeta) {
        this.idmeta = idmeta;
    }

    public int getUser() {
        return user;
    }

    public void setUser(int user) {
        this.user = user;
    }

    public String getTagini() {
        return tagini;
    }

    public void setTagini(String tagini) {
        this.tagini = tagini;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public int getGrupo() {
        return grupo;
    }

    public void setGrupo(int grupo) {
        this.grupo = grupo;
    }



}
