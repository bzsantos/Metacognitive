/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bz.metric.model;

/**
 *
 * @author bzsantos
 */
public class Metatags {
    private int idmetatag;
    private int folks;
    private String tags;
    private int grupos;

    public int getIdmetatag() {
        return idmetatag;
    }

    public void setIdmetatag(int idmetatag) {
        this.idmetatag = idmetatag;
    }

    public int getFolks() {
        return folks;
    }

    public void setFolks(int folks) {
        this.folks = folks;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public int getGrupos() {
        return grupos;
    }

    public void setGrupos(int grupos) {
        this.grupos = grupos;
    }
    
    
    
    
}
