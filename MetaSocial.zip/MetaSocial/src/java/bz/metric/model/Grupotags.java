/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bz.metric.model;

/**
 *
 * @author bzsantos
 */
public class Grupotags {
    private int idgruupo;
    private int metasort;
    private int  folks;
    private String tags;
    private int grupo;

    public int getIdgruupo() {
        return idgruupo;
    }

    public void setIdgruupo(int idgruupo) {
        this.idgruupo = idgruupo;
    }

    public int getMetasort() {
        return metasort;
    }

    public void setMetasort(int metasort) {
        this.metasort = metasort;
    }    

    public int getFolks() {
        return folks;
    }

    public void setFolks(int folks) {
        this.folks = folks;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public int getGrupo() {
        return grupo;
    }

    public void setGrupo(int grupo) {
        this.grupo = grupo;
    }
    
    
            
            
    
}
