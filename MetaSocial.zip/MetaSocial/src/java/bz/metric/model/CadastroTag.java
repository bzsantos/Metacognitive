/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bz.metric.model;

/**
 *
 * @author bzsantos
 */
public class CadastroTag {

    private int idinicio;
    private int user;
    private String tagini;
    private String linktag;
    private int grupo;
    private int sugestao;

    public int getIdinicio() {
        return idinicio;
    }

    public void setIdinicio(int idinicio) {
        this.idinicio = idinicio;
    }

    public int getUser() {
        return user;
    }

    public void setUser(int user) {
        this.user = user;
    }

    public String getTagini() {
        return tagini;
    }

    public void setTagini(String tagini) {
        this.tagini = tagini;
    }

    public String getLinktag() {
        return linktag;
    }

    public void setLinktag(String linktag) {
        this.linktag = linktag;
    }

    public int getGrupo() {
        return grupo;
    }

    public void setGrupo(int grupo) {
        this.grupo = grupo;
    }

    public int getSugestao() {
        return sugestao;
    }

    public void setSugestao(int sugestao) {
        this.sugestao = sugestao;
    }
    
    

}
