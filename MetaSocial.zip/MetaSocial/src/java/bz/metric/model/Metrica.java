/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bz.metric.model;

/**
 *
 * @author bzsantos
 */
public class Metrica {
    
    private int idmetrica;
    private int taxodicio;
    private int metatag;
    private double kma;
    private double kmb;
    private double nac;
    private int qtcompartilhada;
    private String tagm;

    public int getIdmetrica() {
        return idmetrica;
    }

    public void setIdmetrica(int idmetrica) {
        this.idmetrica = idmetrica;
    }

    public int getTaxodicio() {
        return taxodicio;
    }

    public void setTaxodicio(int taxodicio) {
        this.taxodicio = taxodicio;
    }

    public int getMetatag() {
        return metatag;
    }

    public void setMetatag(int metatag) {
        this.metatag = metatag;
    }

    public double getKma() {
        return kma;
    }

    public void setKma(double kma) {
        this.kma = kma;
    }

    public double getKmb() {
        return kmb;
    }

    public void setKmb(double kmb) {
        this.kmb = kmb;
    }

    public double getNac() {
        return nac;
    }

    public void setNac(double nac) {
        this.nac = nac;
    }

    public int getQtcompartilhada() {
        return qtcompartilhada;
    }

    public void setQtcompartilhada(int qtcompartilhada) {
        this.qtcompartilhada = qtcompartilhada;
    }

    public String getTagm() {
        return tagm;
    }

    public void setTagm(String tagm) {
        this.tagm = tagm;
    }
 
    

  
    
    
    
    
}
