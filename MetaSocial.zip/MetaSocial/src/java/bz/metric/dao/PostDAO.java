package bz.metric.dao;

import bz.metric.model.Metatags;
import bz.metric.model.Post;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PostDAO extends GenericDAO {

    private static PostDAO instance;

    static {
        instance = new PostDAO();
    }

    public PostDAO() {
    }

    public static PostDAO getInstance() {
        return instance;
    }

    public boolean salvar(Post dados) {

        Connection conn = Conexao.getConnection();
        PreparedStatement pstmt;
        boolean retorno = true;
        try {
            pstmt = conn.prepareStatement(
                    "INSERT INTO post (idpost, grupotitulo, subtitulo, tag1, tag2, tag3, tag4, foto, usuario) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

            pstmt.setInt(1, dados.getIdpost());
            pstmt.setString(2, dados.getGrupotitulo());
            pstmt.setString(3, dados.getSubtitulo());
            pstmt.setString(4, dados.getTag1());
            pstmt.setString(5, dados.getTag2());
            pstmt.setString(6, dados.getTag3());
            pstmt.setString(7, dados.getTag4());
            pstmt.setString(8, dados.getFoto());
            pstmt.setInt(9, dados.getUsuario());

            pstmt.executeUpdate();
            conn.close();
        } catch (SQLException ex) {
            retorno = false;
            ex.printStackTrace();
        }
        return retorno;

    }

    public boolean apagar(Post dados) {

        boolean retorno = true;
        Connection conn = Conexao.getConnection();
        try {
            Statement stmt = conn.createStatement();
            stmt.executeUpdate("DELETE FROM post WHERE idpost = " + dados.getIdpost());
            conn.close();
        } catch (SQLException ex) {
            retorno = false;
            ex.printStackTrace();
        }
        return retorno;

    }

    public boolean update(Post dados) {

        boolean retorno = true;
        Connection conn = Conexao.getConnection();
        PreparedStatement pstmt;
        try {
            pstmt = conn.prepareStatement(
                    "UPDATE post SET "
                    + "idpost = ?, grupotitulo = ?, subtitulo = ?, tag1 = ?, tag2 = ?, tag3 = ?, tag4 = ?, foto = ?, usuario = ? "
                    + "WHERE idpost = " + dados.getIdpost());

            pstmt.setInt(1, dados.getIdpost());
            pstmt.setString(2, dados.getGrupotitulo());
            pstmt.setString(3, dados.getSubtitulo());
            pstmt.setString(4, dados.getTag1());
            pstmt.setString(5, dados.getTag2());
            pstmt.setString(6, dados.getTag3());
            pstmt.setString(7, dados.getTag4());
            pstmt.setString(8, dados.getFoto());
            pstmt.setInt(9, dados.getUsuario());
            pstmt.executeUpdate();
            conn.close();
        } catch (SQLException ex) {
            retorno = false;
            ex.printStackTrace();
        }
        return retorno;

    }

    public Post ler(Post dados) {

        PreparedStatement pstmt = null;

        int updateQuery = 0;

        Post dadosAux = new Post();
        Connection conn = Conexao.getConnection();
        boolean retorno = true;

        try {
            Statement stmt = conn.createStatement();

            ResultSet rs = stmt.executeQuery("SELECT * FROM post WHERE idpost ='" + dados.getIdpost() + "'");
            // ResultSet rs = stmt.executeQuery("SELECT * FROM users WHERE id_usuario =" + dados.getId_usuario()) ;

            if (rs.next()) {
                dadosAux = carregaMetatags(dados, rs);

            } else {
                dados = null;
            }

            //  statement.executeUpdate("INSERT INTO user" + "VALUES('" + dado.getId() + "'");
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            retorno = false;
        }
        return dados;

    }

    private Post carregaMetatags(Post dadosAux, ResultSet rs) throws SQLException {

        //Metatags dadosAux = new Metatags();
        dadosAux.setIdpost(rs.getInt("idpost"));
        dadosAux.setGrupotitulo(rs.getString("grupotitulo"));
        dadosAux.setSubtitulo(rs.getString("subtitulo"));
        dadosAux.setTag1(rs.getString("tag1"));
        dadosAux.setTag2(rs.getString("tag2"));
        dadosAux.setTag3(rs.getString("tag3"));
        dadosAux.setTag4(rs.getString("tag4"));
        dadosAux.setFoto(rs.getString("foto"));
        dadosAux.setUsuario(rs.getInt("usuario"));

        return dadosAux;
    }

//    public Post EncontraByTag(String tag) throws SQLException {
//
//        String select = "SELECT * FROM post WHERE tag = ?";
//        Post dadosAux = null;
//
//        try (PreparedStatement stmt = getConnection().prepareStatement(select)) {
//            stmt.setString(1, tag);
//            try (ResultSet rs = stmt.executeQuery()) {
//                while (rs.next()) {
//
//                    dadosAux.setIdpost(rs.getInt("idpost"));
//                    dadosAux.setTitulo(rs.getString("grupotitulo"));
//                    dadosAux.setSubtitulo(rs.getString("subtitulo"));
//                    dadosAux.setTag(rs.getString("tag"));
//                    dadosAux.setFoto(rs.getString("foto"));
//                    dadosAux.setUsuario(rs.getInt("usuario"));
//
//                }
//            }
//        }
//        return dadosAux;
//    }
    public List<Post> EncontraGrupoTags() throws SQLException {
        List<Post> contatos = new ArrayList<>();
        String select = "SELECT * FROM post";
        //String select = "select folks, tags, grupo from grupotag group by tags order by folks desc";
        try (PreparedStatement stmt = getConnection().prepareStatement(select); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Post dadosAux = new Post();
                dadosAux.setIdpost(rs.getInt("idpost"));
                dadosAux.setGrupotitulo(rs.getString("grupotitulo"));
                dadosAux.setSubtitulo(rs.getString("subtitulo"));
                dadosAux.setTag1(rs.getString("tag1"));
                dadosAux.setTag2(rs.getString("tag2"));
                dadosAux.setTag3(rs.getString("tag3"));
                dadosAux.setTag4(rs.getString("tag4"));
                dadosAux.setFoto(rs.getString("foto"));
                dadosAux.setUsuario(rs.getInt("usuario"));

                contatos.add(dadosAux);
            }
        }
        return contatos;
    }

}
