/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bz.metric.dao;

import bz.metric.model.Metatags;
import bz.metric.model.Post;
import bz.metric.model.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author bzsantos
 */
public class UserDAO extends GenericDAO {

    private static UserDAO instance;

    static {
        instance = new UserDAO();
    }

    public UserDAO() {
    }

    public static UserDAO getInstance() {
        return instance;
    }

    public boolean criausuario(Usuario dados) {

        Connection conn = Conexao.getConnection();
        PreparedStatement pstmt;
        boolean retorno = true;
        try {
            pstmt = conn.prepareStatement(
                    "INSERT INTO usuario(idusuario,login,senha,nome,nivel_user,foto) VALUES (?,?,?,?,?,?)");

            pstmt.setInt(1, dados.getIdusuario());
            pstmt.setString(2, dados.getLogin());
            pstmt.setString(3, dados.getSenha());
            pstmt.setString(4, dados.getNome());
            pstmt.setInt(5, dados.getNivel());
            pstmt.setString(6, dados.getFoto());

//            pstmt.setString(9, dados.getLink());
//            pstmt.setString(10, dados.getGassunto());
            pstmt.executeUpdate();
            conn.close();
        } catch (SQLException ex) {
            //  retorno = false;
            ex.printStackTrace();
        }
        return retorno;

    }

    public Usuario login(Usuario dados) {

        PreparedStatement pstmt = null;

        int updateQuery = 0;

        Usuario dadosAux = new Usuario();
        Connection conn = Conexao.getConnection();
        boolean retorno = true;

        try {
            Statement stmt = conn.createStatement();

            ResultSet rs = stmt.executeQuery("SELECT login, senha FROM usuario WHERE login ='" + dados.getLogin() + "'" + "AND senha ='" + dados.getSenha() + "'");
            // ResultSet rs = stmt.executeQuery("SELECT * FROM users WHERE id_usuario =" + dados.getId_usuario()) ;

            if (rs.next() == true) {
                dadosAux = carregaUsuarios(dados, rs);
//                JOptionPane.showMessageDialog(null, "Logado");

            } else {
                dados = null;
//                JOptionPane.showMessageDialog(null, "Não Logado");
            }

            //  statement.executeUpdate("INSERT INTO user" + "VALUES('" + dado.getId() + "'");
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            retorno = false;
        }
        return dados;

    }

    private Usuario carregaUsuarios(Usuario dadosAux, ResultSet rs) throws SQLException {

        //Metatags dadosAux = new Metatags();
        // dadosAux.setIdusuario(rs.getInt("idusuario"));
        dadosAux.setLogin(rs.getString("login"));
        dadosAux.setSenha(rs.getString("senha"));

        return dadosAux;
    }

    public boolean delete(Usuario dados) {

        boolean retorno = true;
        Connection conn = Conexao.getConnection();
        try {
            Statement stmt = conn.createStatement();
            stmt.executeUpdate("DELETE FROM usuario WHERE idusuario = " + dados.getIdusuario());
            conn.close();
        } catch (SQLException ex) {
            retorno = false;
            ex.printStackTrace();
        }
        return retorno;

    }

//    public Usuario EncontraByUser(Usuario dados) throws SQLException {
//
//        String select = "SELECT * FROM usuario WHERE ='" + dados.getLogin() + "'";
//        Usuario dadosAux = null;
//
//        try (PreparedStatement stmt = getConnection().prepareStatement(select)) {
//            stmt.setString(1, dados.getLogin());
//            try (ResultSet rs = stmt.executeQuery()) {
//                while (rs.next()) {
//
//                    dadosAux.setIdusuario(rs.getInt("idusuario"));
//                    dadosAux.setLogin(rs.getString("login"));
//                    dadosAux.setSenha(rs.getString("senha"));
//                    dadosAux.setNome(rs.getString("nome"));
//                    dadosAux.setNivel(rs.getInt("nivel_user"));
//                    dadosAux.setFoto(rs.getString("foto"));
//
//                }
//            }
//        }
//        return dadosAux;
//    }

    public Usuario usuario(Usuario dados) {

        PreparedStatement pstmt = null;

        int updateQuery = 0;

        Usuario dadosAux = new Usuario();
        Connection conn = Conexao.getConnection();
        boolean retorno = true;

        try {
            Statement stmt = conn.createStatement();

            ResultSet rs = stmt.executeQuery("SELECT * FROM usuario WHERE login ='" + dados.getLogin() + "'");
            // ResultSet rs = stmt.executeQuery("SELECT * FROM users WHERE id_usuario =" + dados.getId_usuario()) ;

            if (rs.next() == true) {
                dadosAux = carregaTudo(dados, rs);
//                JOptionPane.showMessageDialog(null, "Logado");

            } else {
                dados = null;
//                JOptionPane.showMessageDialog(null, "Não Logado");
            }

            //  statement.executeUpdate("INSERT INTO user" + "VALUES('" + dado.getId() + "'");
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            retorno = false;
        }
        return dados;

    }

    private Usuario carregaTudo(Usuario dadosAux, ResultSet rs) throws SQLException {

        dadosAux.setIdusuario(rs.getInt("idusuario"));
        dadosAux.setLogin(rs.getString("login"));
        dadosAux.setSenha(rs.getString("senha"));
        dadosAux.setNome(rs.getString("nome"));
        dadosAux.setNivel(rs.getInt("nivel_user"));
        dadosAux.setFoto(rs.getString("foto"));

        return dadosAux;
    }

}
