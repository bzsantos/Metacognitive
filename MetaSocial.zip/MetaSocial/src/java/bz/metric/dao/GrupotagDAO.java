package bz.metric.dao;

import bz.metric.model.Grupotags;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author bzsantos
 */
public class GrupotagDAO extends Grupotags {

    private static GrupotagDAO instance;

    static {
        instance = new GrupotagDAO();
    }

    public GrupotagDAO() {
    }

    public static GrupotagDAO getInstance() {
        return instance;
    }

    public boolean insertmetabase(String basedados) {

        Grupotags dados = new Grupotags();

        Connection conn = Conexao.getConnection();
        PreparedStatement pstmt;
        boolean retorno = true;
        try {
            pstmt = conn.prepareStatement(
                    "LOAD DATA LOCAL INFILE 'c:/tmp/" + basedados + ".csv' INTO TABLE metainicio  CHARACTER SET utf8  FIELDS TERMINATED BY ';'  LINES TERMINATED BY '\\r\\n'  (user, tagini, linktag, grupo_id)");

            pstmt.executeUpdate();
            conn.close();

           // JOptionPane.showMessageDialog(null, "Carregado com sucesso!");

        } catch (SQLException ex) {
            //  retorno = false;
            //  ex.printStackTrace();
          //  JOptionPane.showMessageDialog(null, "Sem registro no diretório");
        }
        return retorno;

    }

    public boolean limparbase() {

        Grupotags dados = new Grupotags();

        Connection conn = Conexao.getConnection();
        PreparedStatement pstmt;
        boolean retorno = true;
        try {
            pstmt = conn.prepareStatement(
                    "	SET SQL_SAFE_UPDATES = 0;\n"
                    + " delete from metainicio;\n"
                    + " SET SQL_SAFE_UPDATES = 1; ");

            pstmt.executeUpdate();
            conn.close();

          //  JOptionPane.showMessageDialog(null, "Carregado com sucesso!");

        } catch (SQLException ex) {
            //  retorno = false;
            //  ex.printStackTrace();
          //  JOptionPane.showMessageDialog(null, "Sem registro no diretório");
        }
        return retorno;

    }

    public boolean insereprocedure(String meta) throws SQLException {

        Connection conn = Conexao.getConnection();
        PreparedStatement pstmt;
        // CallableStatement callableStatement = null;

        boolean retorno = true;

        try {

//            JOptionPane.showMessageDialog(null, "teste tag: " + this.getTags());
//            this.setTags(meta);
//            JOptionPane.showMessageDialog(null, "teste tag: " + this.getTags());
            CallableStatement start = conn.prepareCall("{CALL sp_grupotag(?)}");
            start.setString(1, meta);

            start.executeUpdate();
            conn.close();

        } catch (SQLException ex) {
            retorno = false;
            // ex.printStackTrace();
        }
        return retorno;

    }

    public boolean insereproceduremeta() {

        Connection conn = Conexao.getConnection();
        PreparedStatement pstmt;
        // CallableStatement callableStatement = null;

        boolean retorno = true;

        try {

            CallableStatement start = conn.prepareCall("{CALL sp_metatags()}");

            // start.setString(1, this.getTags());                   
            start.executeUpdate();
            start.close();

            conn.close();
        } catch (SQLException ex) {
            retorno = false;
            ex.printStackTrace();
        }
        return retorno;

    }

    public boolean carregametadados() {

        Connection conn = Conexao.getConnection();
        PreparedStatement pstmt;
        // CallableStatement callableStatement = null;

        boolean retorno = true;

        try {

            CallableStatement start = conn.prepareCall("{CALL sp_carregametadados}");

            // start.setString(1, this.getTags());                   
            start.executeUpdate();
            start.close();

            conn.close();

            JOptionPane.showMessageDialog(null, "Carregado com sucesso!");

        } catch (SQLException ex) {
            retorno = false;
            ex.printStackTrace();

          //  JOptionPane.showMessageDialog(null, "Erro ao Carregar!");
        }
        return retorno;

    }

    public boolean geramemoria() {

        Connection conn = Conexao.getConnection();
        PreparedStatement pstmt;
        // CallableStatement callableStatement = null;

        boolean retorno = true;

        try {

            CallableStatement start = conn.prepareCall("{CALL sp_memoria}");

            // start.setString(1, this.getTags());                   
            start.executeUpdate();
            start.close();

            conn.close();

         //   JOptionPane.showMessageDialog(null, "Carregado com sucesso!");

        } catch (SQLException ex) {
            retorno = false;
            ex.printStackTrace();

         //   JOptionPane.showMessageDialog(null, "Erro ao Carregar!");
        }
        return retorno;

    }

    public boolean geramemoriaindividual() {

        Connection conn = Conexao.getConnection();
        PreparedStatement pstmt;
        // CallableStatement callableStatement = null;

        boolean retorno = true;

        try {

            CallableStatement start = conn.prepareCall("{CALL sp_memoriaindividual}");

            // start.setString(1, this.getTags());                   
            start.executeUpdate();
            start.close();

            conn.close();

         //   JOptionPane.showMessageDialog(null, "Carregado com sucesso!");

        } catch (SQLException ex) {
            retorno = false;
            ex.printStackTrace();

         //   JOptionPane.showMessageDialog(null, "Erro ao Carregar!");
        }
        return retorno;

    }

}
