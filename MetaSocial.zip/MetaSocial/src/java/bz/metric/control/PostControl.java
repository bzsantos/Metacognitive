package bz.metric.control;

import bz.metric.dao.PostDAO;
import bz.metric.model.Post;

public class PostControl extends Post {

    public void cadpost(String titulo, String subtitulo, String tag1, String tag2, String tag3, String tag4, String foto, int usuario) {

        PostDAO post = new PostDAO();

        //this.setIdpost(id);
        this.setGrupotitulo(titulo);
        this.setSubtitulo(subtitulo);
        this.setTag1(tag1);
        this.setTag2(tag2);
        this.setTag3(tag3);
        this.setTag4(tag4);
        this.setFoto(foto);
        this.setUsuario(usuario);

        post.salvar(this);

    }

}
