/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bz.metric.control;

import bz.metric.dao.GrupotagDAO;
import bz.metric.model.Grupotags;
import java.sql.SQLException;

/**
 *
 * @author bzsantos
 */
public class MetarefeControl extends Grupotags {
    
   public void inseremetarefe(String metadado) throws SQLException {
       
       GrupotagDAO tg = new GrupotagDAO();      
       
       tg.insereprocedure(metadado);
       
       
       
   }
    
    
    
    
}
