package bz.metric.control;

import bz.metric.dao.GrupotagDAO;
import bz.metric.dao.MetatagDAO;
import bz.metric.model.Metasort;
import bz.metric.model.Metatags;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class AdicionaTag {
    
    
        public boolean confere(String tg) throws SQLException{
        
        MetatagDAO mt = new MetatagDAO();
        MetricControl mc = new MetricControl();
        
        List<Metasort> resultado = mt.listatags();
        
    
        for(int i=0;i<resultado.size();i++){    
            

            String tag = resultado.get(i).getTagsort();
            
            if(tag.equals(tg)){           
                
                mc.tgg(tg);
                return true;                 
            } 
        }         
        return false;
    }
        
        public ArrayList<String> minhastag() throws SQLException {
            
        MetatagDAO grupodao = new MetatagDAO();
        GrupotagDAO gt =  new GrupotagDAO();

        List<Metatags> resultado;
        ArrayList<String> metacerto = new ArrayList<>();
     
        
        try {
            resultado = grupodao.findGrupoTags();
            
           
            metacerto.add(resultado.get(0).getTags());
            metacerto.add(resultado.get(1).getTags());
            metacerto.add(resultado.get(2).getTags());
         //   metacerto.add(resultado.get(3).getTags());
          
          return metacerto;
            
        } catch (SQLException ex) {
            ex.getStackTrace();
        }
            return null;

        }
       
}


