/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bz.metric.control;

import bz.metric.dao.GrupotagDAO;
import bz.metric.dao.MetatagDAO;
import bz.metric.dao.MetricDAO;
import bz.metric.model.Metatags;
import bz.metric.model.Metrica;
import bz.metric.nac.DadosNac;
import bz.metric.nac.MetricNac;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author bzsantos
 */
public class MetricControl extends MetricNac {

    private int id;
    private int num;
    private String metatag;

    public void tgg(String tag) throws SQLException {
        
        //boolean retorno = false;

        MetatagDAO grupodao = new MetatagDAO();
        GrupotagDAO gt =  new GrupotagDAO();
        
        gt.insereprocedure(tag);
        
        
        List<Metatags> resultado = grupodao.findGrupoTags();
   
//        int i = -1;

//        while (i < 3) {

//            i++;
            
               // retorno = true;
            
            String[] metacerto = new String[4];
       
                

            metacerto[0] = resultado.get(0).getTags();
            metacerto[1] = resultado.get(1).getTags();
            metacerto[2] = resultado.get(2).getTags();
            metacerto[3] = resultado.get(3).getTags();
            
            
          //  cadmetric(tag);

          for(int i=0;i<metacerto.length;i++) {

            if (metacerto[0].equals(tag)) {

                cadmetric(tag);
                //JOptionPane.showMessageDialog(null, "1º Tag");
                break;
               // return retorno;

            } else if (metacerto[1].equals(tag)) {
                cadmetric(tag);

                //JOptionPane.showMessageDialog(null, "2º Tag");
                break;
                //return retorno;

            } else if (metacerto[2].equals(tag)) {
                cadmetric(tag);

                //JOptionPane.showMessageDialog(null, "3º Tag");
                break;
                //return retorno;

            } else if (metacerto[3].equals(tag)) {
                cadmetric(tag);

                //JOptionPane.showMessageDialog(null, "4º Tag");
               
                break;
               //return retorno;

            } else {
                
                //semtag(tag);
                cadno(tag);
                System.out.println("Sem a Tag");

                break;
               //return retorno;
            }
          }   
          
        }
        

    public void cadmetric(String tag) throws SQLException {

//        tgg(tag);
        Metrica metrica = new Metrica();
        DadosNac metindice = new DadosNac();

        MetricDAO me = new MetricDAO();
        MetricNac n = new MetricNac();
       

        MetatagDAO grupodao = new MetatagDAO();
        List<Metatags> resultado = grupodao.findGrupoTags();

        resultado.get(0).getFolks();

//        n.kmetrics(tag);
//        try{
//            n.mets(tag);
//        } catch(SQLException e) {
//            e.getStackTrace();
//        }
        for (int i = 0; i < resultado.size(); i++) {

            if (resultado.get(i).getTags().equals(tag)) {

                n.mets(tag, tag);

//                int id; 
//                int num; 
//                id = resultado.get(i).getIdmetatag();
//                num = resultado.get(i).getFolks();
                this.setId(resultado.get(i).getIdmetatag());
                this.setNum(resultado.get(i).getFolks()); //pega todos os valores da folksonomia

              //  JOptionPane.showMessageDialog(null, "id: " + this.getId());

              //  JOptionPane.showMessageDialog(null, "folks: " + this.getNum());

                this.setNumtotal(this.getNum());

                grupodao.findGrupoTags().get(0);

                //metrica.setIdmetrica(1);
                //metrica.setTaxodicio(1);
                metrica.setMetatag(id);
                metrica.setKma(n.ka());
                metrica.setKmb(n.kb());
                metrica.setNac(n.nc());
                metrica.setQtcompartilhada(this.getNum());
                metrica.setTagm(tag);
                //     metrica.setLink("");
                //     metrica.setGassunto("");

                me.criametrica(metrica);

                break;

            }

        }

    }
    
  
    
    public void cadno(String tag) throws SQLException {
     

//        tgg(tag);
        Metrica metrica = new Metrica();
        DadosNac metindice = new DadosNac();

        MetricDAO me = new MetricDAO();
        MetricNac n = new MetricNac();
    

        MetatagDAO grupodao = new MetatagDAO();
        List<Metatags> resultado = grupodao.findGrupoTags();

        resultado.get(0).getFolks();

//        n.kmetrics(tag);
//        try{
//            n.mets(tag);
//        } catch(SQLException e) {
//            e.getStackTrace();
//        }
        for (int i = 0; i < resultado.size(); i++) {

            if (resultado.get(i).getTags().equals(tag)) {
                
                String tag3 = resultado.get(3).getTags();

                n.mets(tag3, tag);

//                int id; 
//                int num; 
//                id = resultado.get(i).getIdmetatag();
//                num = resultado.get(i).getFolks();
                this.setId(resultado.get(i).getIdmetatag());
                this.setNum(resultado.get(i).getFolks());

               // JOptionPane.showMessageDialog(null, "id: " + this.getId());

               // JOptionPane.showMessageDialog(null, "folks: " + this.getNum());

                this.setNumtotal(this.getNum());

                grupodao.findGrupoTags().get(0);

                //metrica.setIdmetrica(1);
                //metrica.setTaxodicio(1);
                metrica.setMetatag(id);
                metrica.setKma(n.ka());
                metrica.setKmb(n.kb());
                metrica.setNac(n.nc());
                metrica.setQtcompartilhada(this.getNum());
                metrica.setTagm(tag);
                
                //     metrica.setLink("");
                //     metrica.setGassunto("");

                me.criametrica(metrica);

                break;

            } 

        }

    }
    
   

    public void semtag(String tag) throws SQLException {

        Metrica metrica = new Metrica();
        DadosNac metindice = new DadosNac();

        MetricDAO me = new MetricDAO();
        MetricNac n = new MetricNac();
     

        MetatagDAO grupodao = new MetatagDAO();
        DadosNac dn = new DadosNac();
        List<Metatags> resultado = grupodao.findGrupoTags();

//        resultado.get(0).getFolks();
        for (int z = 0; z < resultado.size(); z++) {
//            if (!resultado.get(i).getTags().equals(tag)) {

            if (!tag.equals(resultado.get(z).getTags())) {

            //    String tag1 = resultado.get(4).getTags();
//
                //tag = "maça";

                n.mets(tag, tag);

//                int id; 
//                int num; 
//                id = resultado.get(i).getIdmetatag();
//                num = resultado.get(i).getFolks();
                this.setId(resultado.get(z).getIdmetatag());
                this.setNum(resultado.get(4).getFolks());

             //   JOptionPane.showMessageDialog(null, "id: " + this.getId());

            //    JOptionPane.showMessageDialog(null, "folks: " + this.getNum());

                this.setNumtotal(this.getNum());

                grupodao.findGrupoTags().get(0);

                //metrica.setIdmetrica(1);
                //metrica.setTaxodicio(1);
                metrica.setMetatag(id);
                metrica.setKma(n.ka() / 5);
                metrica.setKmb(n.kb() / 5);
                metrica.setNac(n.nc() / 5);
                metrica.setQtcompartilhada(this.getNum() - 1);
                metrica.setTagm(tag);
                //     metrica.setLink("");
                //     metrica.setGassunto("");

                me.criametrica(metrica);
                
            
//            dn.setMetadado(tag);
//            
//            dn.setEscalaklm(nc());
//            
//            dn.setIndice("Inadequado");
//            
//            dn.setMetrica("MAB");
//            
//            dn.setInterpretacao("O metadado utilizado possui um nível baixo de conhecimento.");
//            
//
//                dn.getMetadado();
//                dn.getEscalaklm();
//                dn.getIndice();
//                dn.getInterpretacao();
//                
//                me.metricaindice(dn);   
                
                
                
                break;

            }
            //break;
        }

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getMetatag() {
        return metatag;
    }

    public void setMetatag(String metatag) {
        this.metatag = metatag;
    }
    
    

}
