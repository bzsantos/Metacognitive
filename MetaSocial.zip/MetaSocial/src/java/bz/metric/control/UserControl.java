/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bz.metric.control;

import bz.metric.dao.UserDAO;
import bz.metric.model.Usuario;
import java.sql.SQLException;

/**
 *
 * @author bzsantos
 */
public class UserControl extends Usuario {
    
    
  public boolean caduser(String login, String senha, String nome, int nivel){
      
      UserDAO d = new UserDAO();
      
      this.setLogin(login);
      this.setSenha(senha);
      this.setNome(nome);
      this.setNivel(nivel);
      
     // d.criausuario(this);
      
        if(d.criausuario(this) != false){
          return true;
      } else {
          return false;      }
          
  }
  
  public boolean login(String login, String senha){
      
      UserDAO d = new UserDAO();
      
      this.setLogin(login);
      this.setSenha(senha);
      
      if(d.login(this) != null){
          return true;
      } else {
          return false;      }
      
      //return true;
      
  }
  
//  public boolean userlogado(String login) throws SQLException{
//      
//      UserDAO d = new UserDAO();
//      
//      this.setLogin(login);
//      
//      d.EncontraByUser(this);
//      
//      
//          
//       
//      return false;
//  }
  
  
  
    
    
    
    
    
}
