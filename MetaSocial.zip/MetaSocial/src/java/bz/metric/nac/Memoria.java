package bz.metric.nac;


public class Memoria {
//idmetamodelo
//metrica
//nac
//qtcom
//tagmeta
//link
//grupoassunto
    
}
