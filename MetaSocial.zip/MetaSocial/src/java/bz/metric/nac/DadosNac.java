package bz.metric.nac;

/**
 *
 * @author Bruno Zolotareff dos Santos
 */
public class DadosNac {

    private double R;
    private double AP;
    private double EMO;
    private double EMP;
    private double EGO;
    private double EGP;
    private double QP;
    private double ka;
    private double kb;
    private double nac;
    String metadado;
    double[] meta;
    String[] metacerto;
    private double EFGP; //Erro de Folksonomia Grande Pessimista
    private double EFMO;
    private double EFGO;
    private double EFMP;
    private int tag1; //primeiro metadado
    private int tag2; //segundo metadado
    private int tag3; //terceiro metadado
    private int tag4; //quatro metadado
    private int tag5; //cinco metadado
    private int tag6; //seis metadado
    private int tag7; //sete metadado
    private int idindice;   
    private String letag;
    private String indice;
    private String metrica;
    private String interpretacao;
    private double escalaklm;

    
    public double getR() {
        return R;
    }

    public void setR(double R) {
        this.R = R;
    }    
    
    public String getLetag() {
        return letag;
    }

    public void setLetag(String letag) {
        this.letag = letag;
    }

    public String getMetadado() {
        return metadado;
    }

    public void setMetadado(String metadado) {
        this.metadado = metadado;
    }

    public double[] getMeta() {
        return meta;
    }

    public void setMeta(double[] meta) {
        this.meta = meta;
    }

    public String[] getMetacerto() {
        return metacerto;
    }

    public void setMetacerto(String[] metacerto) {
        this.metacerto = metacerto;
    }  

    public double getAP() {
        return AP;
    }

    public void setAP(double AP) {
        this.AP = AP;
    }

    public double getEMO() {
        return EMO;
    }

    public void setEMO(double EMO) {
        this.EMO = EMO;
    }

    public double getEMP() {
        return EMP;
    }

    public void setEMP(double EMP) {
        this.EMP = EMP;
    }

    public double getEGO() {
        return EGO;
    }

    public void setEGO(double EGO) {
        this.EGO = EGO;
    }

    public double getEGP() {
        return EGP;
    }

    public void setEGP(double EGP) {
        this.EGP = EGP;
    }

    public double getQP() {
        return QP;
    }

    public void setQP(double QP) {
        this.QP = QP;
    }

    public double getKa() {
        return ka;
    }

    public void setKa(double ka) {
        this.ka = ka;
    }

    public double getKb() {
        return kb;
    }

    public void setKb(double kb) {
        this.kb = kb;
    }

    public double getNac() {
        return nac;
    }

    public void setNac(double nac) {
        this.nac = nac;
    }

    public double getEFGP() {
        return EFGP;
    }

    public void setEFGP(double EFGP) {
        this.EFGP = EFGP;
    }

    public double getEFMO() {
        return EFMO;
    }

    public void setEFMO(double EFMO) {
        this.EFMO = EFMO;
    }

    public double getEFGO() {
        return EFGO;
    }

    public void setEFGO(double EFGO) {
        this.EFGO = EFGO;
    }

    public double getEFMP() {
        return EFMP;
    }

    public void setEFMP(double EFMP) {
        this.EFMP = EFMP;
    }

    public int getTag1() {
        return tag1;
    }

    public void setTag1(int tag1) {
        this.tag1 = tag1;
    }

    public int getTag2() {
        return tag2;
    }

    public void setTag2(int tag2) {
        this.tag2 = tag2;
    }

    public int getTag3() {
        return tag3;
    }

    public void setTag3(int tag3) {
        this.tag3 = tag3;
    }

    public int getTag4() {
        return tag4;
    }

    public void setTag4(int tag4) {
        this.tag4 = tag4;
    }

    public int getTag5() {
        return tag5;
    }

    public void setTag5(int tag5) {
        this.tag5 = tag5;
    }

    public int getTag6() {
        return tag6;
    }

    public void setTag6(int tag6) {
        this.tag6 = tag6;
    }

    public int getTag7() {
        return tag7;
    }

    public void setTag7(int tag7) {
        this.tag7 = tag7;
    }
    
    
    
    
    
    
    
    
    

    public int getIdindice() {
        return idindice;
    }

    public void setIdindice(int idindice) {
        this.idindice = idindice;
    }
    
    public String getIndice() {
        return indice;
    }

    public void setIndice(String indice) {
        this.indice = indice;
    }

    public String getMetrica() {
        return metrica;
    }

    public void setMetrica(String metrica) {
        this.metrica = metrica;
    }

    public String getInterpretacao() {
        return interpretacao;
    }

    public void setInterpretacao(String interpretacao) {
        this.interpretacao = interpretacao;
    }

    public double getEscalaklm() {
        return escalaklm;
    }

    public void setEscalaklm(double escalaklm) {
        this.escalaklm = escalaklm;
    }
    
    
    
    
    
    

}
