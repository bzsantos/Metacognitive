package bz.metric.nac;

import bz.metric.control.MetricControl;
import bz.metric.model.Grupotags;
import bz.metric.dao.MetatagDAO;
import bz.metric.dao.MetricDAO;
import bz.metric.model.Metasort;
import bz.metric.model.Metatags;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Bruno Zolotareff dos Santos
 */
public class MetricNac extends DadosNac {

    private int numtotal;
    public String supertag;
    String globaltag;

    public double kmetrics() throws SQLException {
        //this.mets(tag);

        return nac(kma(this.getR(), this.getAP(), this.getEFMO(), this.getEFMP(), this.getEFGO(), this.getEFGP(), this.getQP()), kmb(this.getEFMO(), this.getEFMP(), this.getEFGO(), this.getEFGP(), this.getQP()));
    }

    public double ka() throws SQLException {

        double ka = kma(this.getR(), this.getAP(), this.getEFMO(), this.getEFMP(), this.getEFGO(), this.getEFGP(), this.getQP());

        return ka;
    }

    public double kb() throws SQLException {

        double kb = kmb(this.getEFMO(), this.getEFMP(), this.getEFGO(), this.getEFGP(), this.getQP());

        return kb;
    }

    public double nc() throws SQLException {

        double ka = kma(this.getR(), this.getAP(), this.getEFMO(), this.getEFMP(), this.getEFGO(), this.getEFGP(), this.getQP());

        double kb = kmb(this.getEFMO(), this.getEFMP(), this.getEFGO(), this.getEFGP(), this.getQP());

        double nc = ka + kb;

        //JOptionPane.showMessageDialog(null, "NAC323232323: " + kb);

        System.out.println("nac1: " + nc);

        return nc;
    }

    public double kma(double R, double AP, double EMO, double EMP, double EGO, double EGP, double QP) {

        //double ka = ((AP * 1.00) + ((EMO + EMP) * -0.50) + ((EGO + EGP) * -1.00)) / QP;
        //double ka = R * (AP + (((EMO + EMP)/2 * -0.50)) + ((EGO + EGP) * -1.00)) / QP;
        double ka = R * (AP + (((EMO + EMP) * -0.50)) + ((EGO + EGP) * -1.00)) / QP;
      
        

        System.out.println("Valor kma: " + ka);

        return ka;
    }

    public double kmb(double EMO, double EMP, double EGO, double EGP, double QP) {

        double kb = ((EMO * 0.50) + (EMP * -0.50) + (EGO * 1.00) + (EGP * -1.00)) / QP;

        System.out.println("Valor kmb: " + kb);

        return kb;

    }

    public double nac(double kma, double kmb) {
        //retorna nac
        System.out.println("Valor nac: " + (kma + kmb));

        double totalkms = kma + kmb;

        return totalkms;
    }

    
    
    public void mets(String metadado, String tag2) throws SQLException {

        this.setMetadado(metadado); //Valor que será atrubuído pelo usuário     

        MetricControl mc = new MetricControl();

        MetatagDAO grupodao = new MetatagDAO();

        List<Metatags> resultado = grupodao.findGrupoTags();

        // List<Grupotags> grupolist = grupodao.listaGrupo(); 
//        resultado.get(0).getTags();

        // JOptionPane.showMessageDialog(null,this.getAP());
        int tagone; //valor da folksonomia do 1º metadado
        int tagAp; //irá ter o valor do AP real
        int tagQp; //irá ter o valor do Qp real       
        String tag; //primeiro metadado

        tag = resultado.get(0).getTags();      

        int mtcerto = 0;
        double mt = 0;
        
        
        for (int i = 0; i < resultado.size(); i++) {
   
            String[] metacerto = new String[4];
            double[] meta = new double[4];
     
            metacerto[i] = resultado.get(i).getTags();
            meta[i] = resultado.get(i).getFolks();

            
            if (metacerto[i].equals(metadado)) {


                mc.setId(resultado.get(i).getIdmetatag());
                mc.setNum(resultado.get(i).getFolks());

                tagQp = resultado.get(0).getFolks();

                tagAp = mc.getNum();

              //  JOptionPane.showMessageDialog(null, "Tag AP: " + tagAp);
             //   JOptionPane.showMessageDialog(null, "Tag QP: " + tagQp);

                this.setAP(tagAp);
                this.setQP(tagQp);

                this.setTag1(resultado.get(0).getFolks());
                this.setTag2(resultado.get(1).getFolks());
                this.setTag3(resultado.get(2).getFolks());
                this.setTag4(resultado.get(3).getFolks());
//                this.setTag5(resultado.get(4).getFolks());
                //this.setTag6(resultado.get(5).getFolks());
                double[] xValues = {this.getAP(),this.getAP(),this.getAP(),this.getAP()};
                double[] yValues = {this.getTag1(),this.getTag2(),this.getTag3(),this.getTag4()};                
                
                this.setR(this.calculateR(xValues, yValues));
       
                
                
                if (tagAp == this.getTag1()) {

                    this.setEFMO(1.00);//EMO = quantidade de erros do tipo “médio otimista”, em que se estima acertar parcialmente e erra completamente ou se estima acertar completamente e acerta parcialmente o problema.
                    this.setEFGP(0.00);//EGP = quantidade de erros do tipo “grande pessimista(gp)”, em que se estima errar e acerta completamente o problema.
                    this.setEFMP(1.00);//EMP = quantidade de erros do tipo “médio pessimista”, em que se estima acertar parcialmente e acerta completamente ou se estima errar e acerta parcialmente o problema.
                    this.setEFGO(1.00);//EGO = quantidade de erros do tipo “grande otimista(go)”, em que se estima acertar e erra completamente o problema
                    
                  //   JOptionPane.showMessageDialog(null, "Tag1");

                    break;
                    
                } else if (tagAp == this.getTag2()) {

                    this.setEFMO(0.50); //VIFA - VAI
                    this.setEFGP(0.00); //VSFP - VCP
                    this.setEFMP(0.50); //VFIP - VIP
                    this.setEFGO(0.50); //VSFA - VAP
                 //    JOptionPane.showMessageDialog(null, "Tag2");

                    break;

                } else if (tagAp == this.getTag3()) {

                    this.setEFMO(0.25);
                    this.setEFGP(0.00);
                    this.setEFMP(0.25);
                    this.setEFGO(0.25);
                    
                //    JOptionPane.showMessageDialog(null, "Tag3");

                    break;
                                              
                } else {
                    this.setEFMO(-1.00);
                    this.setEFGP(0.00);
                    this.setEFMP(-1.00);
                    this.setEFGO(-1.00);
                    
               //     JOptionPane.showMessageDialog(null, "Tag4");

                    break;
                }                 
            }                 
        }
        
        for(int x=0;x<5;x++){
        if(resultado.get(x).getTags().equals(metadado)){
            if(x<3){           
                metricindice(metadado);
        } else {
                metricindicefora(tag2);
                            }
        } 
        }
       
    }
        
    public double calculateR(double[] xValues, double[] yValues) {
        int n = xValues.length;

        double sumX = 0;
        double sumY = 0;
        double sumXY = 0;
        double sumX2 = 0;
        double sumY2 = 0;

        for (int i = 0; i < n; i++) {
            sumX += xValues[i];
            sumY += yValues[i];
            sumXY += xValues[i] * yValues[i];
            sumX2 += Math.pow(xValues[i], 2);
            sumY2 += Math.pow(yValues[i], 2);
        }

        double numerator = sumXY;
        double denominator = n * sumY2;

        return numerator / denominator;
    }
    
    
    public void metricindice(String tag) throws SQLException {
        
        DadosNac dn = new DadosNac();
        MetricDAO md = new MetricDAO();

        this.setEscalaklm(nc());

        double klm = nc();

        if (klm >= 0.80) {
            
            dn.setMetadado(tag);
            
            dn.setEscalaklm(nc());
            
            dn.setIndice("Satisfatório");
            
            dn.setMetrica("S");
            
            dn.setInterpretacao("O metadado possui um nível alto de conhecimento.");

                dn.getMetadado();
                dn.getEscalaklm();
                dn.getIndice();
                dn.getInterpretacao();
                
                md.metricaindice(dn);   
            
        } else if (klm >= 0.37 && klm <= 0.80) {
            
            dn.setMetadado(tag);
            
            dn.setEscalaklm(nc());
            
            dn.setIndice("Adequado");
            
            dn.setMetrica("A");
            
            dn.setInterpretacao("O metadado possui um nível médio de conhecimento.");                
                
                dn.getMetadado();
                dn.getEscalaklm();
                dn.getIndice();
                dn.getInterpretacao();
                
               // md.metricaindice(dn);   
            
        } else if (klm < 0.37 && klm <= -2.00) {
            
            dn.setMetadado(tag);
            
            dn.setEscalaklm(nc());
            
            dn.setIndice("Moderado");
            
            dn.setMetrica("M");
            
            dn.setInterpretacao("O metadado utilizado possui um nível baixo de conhecimento.");
           
                dn.getMetadado();
                dn.getEscalaklm();
                dn.getIndice();
                dn.getInterpretacao();
                
               // md.metricaindice(dn);   
            

        } else {
            
            dn.setMetadado(tag);
            
            dn.setEscalaklm(nc());
            
            dn.setIndice("Inadequado");
            
            dn.setMetrica("MAB");
            
            dn.setInterpretacao("O metadado utilizado possui um nível baixo de conhecimento.");
            

                dn.getMetadado();
                dn.getEscalaklm();
                dn.getIndice();
                dn.getInterpretacao();
                
              //  md.metricaindice(dn);   
            
        }        
        md.metricaindice(dn); 
    }


    public String teste(String tag){
       // this.setSupertag(tag);
       
        return tag;
    }
    

  
    
   //Alternativa inclui 
    public void metricindicefora(String tag) throws SQLException {
        
    
            
               
        DadosNac dn = new DadosNac();
        MetricDAO md = new MetricDAO();
   
         //  JOptionPane.showMessageDialog(null, "tags: " + tags);
        // JOptionPane.showMessageDialog(null, "Le tag: " + teste());
      
        
        String tg = globaltag;

        this.setEscalaklm(nc());

        double klm = nc();

        if (klm >= 0.80) {
            
            dn.setMetadado(tag);
            
            dn.setEscalaklm(nc());
            
            dn.setIndice("Satisfatório");
            
            dn.setMetrica("MAA");
            
            dn.setInterpretacao("O metadado possui um nível alto de conhecimento.");

                dn.getMetadado();
                dn.getEscalaklm();
                dn.getIndice();
                dn.getInterpretacao();
                
                md.metricaindice(dn);   
            
        } else if (klm >= 0.37 && klm <= 0.80) {
            
            dn.setMetadado(tag);
            
            dn.setEscalaklm(nc());
            
            dn.setIndice("Adequado");
            
            dn.setMetrica("MAA");
            
            dn.setInterpretacao("O metadado possui um nível médio de conhecimento.");                
                
                dn.getMetadado();
                dn.getEscalaklm();
                dn.getIndice();
                dn.getInterpretacao();
                
               // md.metricaindice(dn);   
            
        } else if (klm < 0.37 && klm <= -2.00) {
            
            dn.setMetadado(tag);
            
            dn.setEscalaklm(nc());
            
            dn.setIndice("Inadequado");
            
            dn.setMetrica("MAB");
            
            dn.setInterpretacao("O metadado utilizado possui um nível baixo de conhecimento.");
           
                dn.getMetadado();
                dn.getEscalaklm();
                dn.getIndice();
                dn.getInterpretacao();
                
               // md.metricaindice(dn);   
            

        } else {
            
            dn.setMetadado(tag);
            
            dn.setEscalaklm(nc());
            
            dn.setIndice("Inadequado");
            
            dn.setMetrica("MAB");
            
            dn.setInterpretacao("O metadado utilizado possui um nível baixo de conhecimento.");
            

                dn.getMetadado();
                dn.getEscalaklm();
                dn.getIndice();
                dn.getInterpretacao();
                
              //  md.metricaindice(dn);   
            
        }        
        md.metricaindice(dn); 
    }
    

    public int getNumtotal() {
        return numtotal;
    }

    public void setNumtotal(int numtotal) {
        this.numtotal = numtotal;
    }

    public String getSupertag() {
        return supertag;
    }

    public void setSupertag(String supertag) {
        this.supertag = supertag;
    }
    
    
    

}
