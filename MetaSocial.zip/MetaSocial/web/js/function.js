// Cody By Webdevtrick ( https://webdevtrick.com )
console.clear();

var el = {};

$('.placeholder').on('click', function (ev) {
  $('.placeholder').css('opacity', '0');
  $('.list__ul').toggle();
 
});

 $('.list__ul a').on('click', function (ev) {
   ev.preventDefault();
   var index = $(this).parent().index();
   
   $('.placeholder').text( $(this).text() ).css('opacity', '1');

   
   console.log($('.list__ul').find('li').eq(index).html());
   
   $('.list__ul').find('li').eq(index).prependTo('.list__ul');
   
   $('.list__ul').toggle();   
   
 });

$('select').on('change', function (e) {
  
  $('.placeholder').text(this.value);
  
  
  
  $(this).animate({width: $('.placeholder').width() + 'px' });
  
 
});

  var chip = {
    tag: 'chip content',
    image: 'img/sa.png' //optional
  };